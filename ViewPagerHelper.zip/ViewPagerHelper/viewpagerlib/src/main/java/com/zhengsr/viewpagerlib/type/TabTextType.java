package com.zhengsr.viewpagerlib.type;

/**
 * created by zhengshaorui on 2019/8/13
 * Describe:
 */
public enum TabTextType {
    NORMAL,
    COLOR
}
