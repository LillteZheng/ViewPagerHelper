package com.zhengsr.viewpagerlib.type;

/**
 * created by zhengshaorui on 2019/8/12
 * Describe: viewpager 的transformer
 */
public enum BannerTransType {
    //卡片式
    CARD,
    //魅族
    MZ,
    //放大
    ZOOM,
    //渐隐
    DEPATH,
    UNKNOWN
}
