package com.zhengsr.viewpagerhelper;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by zhengshaorui
 * time: 2018/9/16
 */
@GlideModule
public class MyAppGlideModule extends AppGlideModule {
}
