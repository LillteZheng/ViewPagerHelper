package com.zhengsr.viewpagerhelper;

import android.app.Application;


/**
 * Created by zhengshaorui
 * time: 2018/9/16
 */

public class MainApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

    }
}
