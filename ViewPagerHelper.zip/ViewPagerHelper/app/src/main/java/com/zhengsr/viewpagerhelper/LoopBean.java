package com.zhengsr.viewpagerhelper;

/**
 * Created by Administrator on 2017/11/9.
 */

public class LoopBean {
    public String url;
    public int res;
    public String text;
}
